package GroupTest.artifactTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ArtifactTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArtifactTestApplication.class, args);
	}

}
