package pl.michalmarciniec.jpatraps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JpaTrapsApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaTrapsApplication.class, args);
	}
}
