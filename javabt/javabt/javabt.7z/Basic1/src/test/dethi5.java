/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Khoale123
 */
public class dethi5 {
    public static void main(String[] args) {
        final int a = 10 ;
        final int b = 20;
        int c = 5;
        while(a<b){
            System.out.print(a);
            
        }
      //  System.out.print(c);
        System.out.print(b);
    }
}
