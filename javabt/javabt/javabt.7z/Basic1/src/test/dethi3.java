/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Khoale123
 */
public class dethi3 {
    public void m1(int a , float b){
        System.out.println("day la 1'");
    }
     public void m1(float c , int d){
        System.out.println("day la 2'");
    }
     
     public static void main(String[] args) {
        dethi3 cc = new dethi3();
        cc.m1(20, 20);
    }
}



