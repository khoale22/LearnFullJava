/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Khoale123
 */
public class testthu {
    public static void main(String[] args) {
           System.out.println("BAI 5");
        int i = 1;
       
        int s = 1;

        for (i = 1; i < 4; i++) {
            s = s * i;
        }

        System.out.println(i);
         System.out.println(s);
        
    }
}
