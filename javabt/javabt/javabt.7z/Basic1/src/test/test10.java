/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Khoale123
 */
public class test10 {
    public static void main(String[] args) {
        
        int a = 5;
        int b = 3;
        
        System.out.println(a>b ? a:b);  // a > b co dung hong dung in ra cai phia truoc sai in ra cai phai sau
         System.out.println(a>b ? b : a);
         
         int x = 4;
         
           System.out.println(x>4 ? 99.99 : 9); // ket qua la 9.0 vi so phai truoc la float
            System.out.println(x>4 ? 99 : 9); // ket qua se la 9
      
         
        
        
    }
}
