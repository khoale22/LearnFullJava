/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

/**
 *
 * @author Khoale123
 */
public class test2 {
       public static void main(String argv[]){
    
      int oi= 012;//  2*8^0 + 1*8^1 --> 2+8 -->10 
   //   int a=0124--> 4*8^0 + 2*8^1 + 1*8^2--> 4+16+64 -->84
      // ! BYTE -128  --- 127
      int ab = 12 ;
      System.out.println(oi);
       System.out.println(ab);
       System.out.println(4 | 3);
   }

}
