/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

/**
 *
 * @author Khoale123
 */
public class biencucbotoancuc {
     int a ; // bien toan cuc mac dinh bang 0
    
     static int c ;
     
     int d ;
     
     static int e;
    void abc(){
       int b; // bien cuc bo phai khoi tao gia tri
        
     
    
    }
    
    public static void main(String[] args) {
        biencucbotoancuc bb = new biencucbotoancuc();
        System.out.println(bb.a);
      ///\    System.out.println(bb.abc());
      
      c = 20;  
      System.out.println(c);
      
      
      bb.d = 30;
      System.out.print(bb.d);
      
      
    }
}
