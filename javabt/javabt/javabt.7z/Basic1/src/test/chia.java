/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

/**
 *
 * @author Khoale123
 */
public class chia {
    public static void main(String[] args) {
        int a = 40 ;
        int b = 15;
        
        
        
      System.out.println(a/b);   // 2 
      System.out.println(a%b);  //   10
      System.out.println(1%10);  // 1
    }
    
}
