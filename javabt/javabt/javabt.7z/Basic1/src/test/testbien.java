/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

/**
 *
 * @author Khoale123
 */
public class testbien {
    
    private static int a ;
    private int b;
    
    
    public static void main(String[] args) {
        testbien c = new testbien();
        
        c.a =10;
        System.out.print(c.a);
          System.out.print(a);
          
         
          


        
    }
}
