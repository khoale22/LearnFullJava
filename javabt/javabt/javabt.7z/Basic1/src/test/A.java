/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Khoale123
 */
public class A {
   static int i ;  // bien toan cuc gia tri mac dinh bang 0;
    public static void main(String[] args) {
        i = i + 1;
        System.out.print(i);
        
    }
    
    


}
