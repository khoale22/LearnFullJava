/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

/**
 *
 * @author Khoale123
 */
public class test8 {
    public static void main(String[] args) {
        String str = null;
        
        switch(str){
            case "null": // case ""; tuong tu loi
                System.out.println("null string");
                break;
            
        }
        // CHAY LOI NULLPOINTERSEXPECION vi string khong co gia con case gia tri la null
    }
}
