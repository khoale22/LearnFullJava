/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Khoale123
 */
public class StringbutferStringbuuetr {

    public static void main(String[] args) {
            String a = null;
            if(a == null || a.name == null){
                System.out.print("ok");

        }
    }
}
