/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package CacThuatToanTrongjava;

/**
 *
 * @author Khoale123
 */
public class NewClass3 {
    public static void main(String[] args) {
//        1
//        12
//        123
//        1234
//        12345
//        
        
            for(int i = 0 ; i<5 ; i++){
               int m =1;
             for(int j =0 ; j<=i ;j++)
            
                {   
                     System.out.print(m+j+" ");
                 }
             System.out.println();
             }
        
              for(int i = 0 ; i<5 ; i++){
               int m =1;
             for(int j =0 ; j<=i ;j++)
            
                {   
                     System.out.print(m+ " ");
                     m++;
                 }
             System.out.println();
             }
        
        
        
    
    }
}
