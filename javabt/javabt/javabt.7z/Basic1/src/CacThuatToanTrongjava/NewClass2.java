/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package CacThuatToanTrongjava;

/**
 *
 * @author Khoale123
 */
public class NewClass2 {
    public static void main(String[] args) {
//        *****
//         ****
//          ***
//           **
//            *
        for(int i = 5 ; i > 0 ;i--){
            for(int k = 5;k > i;k-- )
            {
                  System.out.print(" ");
            }
            for(int j = 0; j < i ;j++)
            {
                 System.out.print("*");
            }
            System.out.println();
        }  
                
                
    }
}
