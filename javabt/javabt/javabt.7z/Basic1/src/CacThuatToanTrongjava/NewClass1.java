/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package CacThuatToanTrongjava;

/**
 *
 * @author Khoale123
 */
public class NewClass1 {
    
//    
//        *
//       **
//      ***
//     ****
//    *****
   
    public static void main(String[] args) {
        
        
         
    
          for(int i = 0; i< 5;i++)
          {   
              for (int k = 0; k < 4 -i ;k++)
              {
                    System.out.print(" ");
              }
              for(int j= 0; j <=i ; j++)
              {
                  System.out.print("*");
              }
              System.out.println();
          }
        
    }
}
