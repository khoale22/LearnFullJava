/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cauHOIphongvan;

import cauHOIphongvan.NewStatic.NewStatic2;

/**
 *
 * @author maich
 */
public class kethua {
    private int tien = 400;
    public int tien2 = 500;

    
    public kethua(int a, int b) {
       
    }
    public void test(){
        System.out.print("test");
    }
      public static void main(String[] args) {
        Counter counter = new Counter();
        System.out.print(Counter.test);
    }
    
}




