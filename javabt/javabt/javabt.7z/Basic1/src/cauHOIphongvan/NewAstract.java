/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cauHOIphongvan;

/**
 *
 * @author maich
 */
public abstract class NewAstract { 
    int a ;
    //asbstract class co the method binh thuong 
    // interface chi co abstract method
    public void tenbien(){
        System.out.println("test");
    }
    protected abstract void tenbien2();
}


