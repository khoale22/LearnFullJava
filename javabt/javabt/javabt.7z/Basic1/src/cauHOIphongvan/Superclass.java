/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cauHOIphongvan;

/**
 *
 * @author maich
 */
public class Superclass {
    int number = 10;
 
    public void hienThi() {
        System.out.println("Đây là phương thức hienThi() của lớp cha");
    }
    
     public void test() {
        System.out.println("TESt lớp cha");
    }
} 


