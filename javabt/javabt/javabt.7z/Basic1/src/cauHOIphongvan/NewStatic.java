/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cauHOIphongvan;

/**
 *
 * @author maich
 */
public class NewStatic {
  //public static class NewStatic : NO 
    
    // class năm trong class thi mới có thể khai báo static
    public static class NewStatic2{
        
    }
    int c;
    public static int ab ;
    public static int ab2;
    
    public static void test() {
        ab = 10;//OK
        ab2 = 10;//OK
    }
     public void test2() {
        ab = 10;//OK
        ab2 = 10;//OK
    }
    
}
   
   
