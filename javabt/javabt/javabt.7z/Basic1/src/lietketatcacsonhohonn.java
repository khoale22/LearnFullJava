
import java.util.Scanner;
import jdk.nashorn.internal.parser.Lexer;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Khoale123
 */
public class lietketatcacsonhohonn {
    public static void main(String[] args) {
        int n ;
        Scanner input = new Scanner(System.in);
        System.out.println("NHap vao so nguyen duong n");
        n = input.nextInt();
        
        for (int i = 1 ; i <= n ; i++){
            for (int j = 1;j <= n ; j++ ){
                
                
                
                
            }
            
        }
            
            
        }
        
        
        
        
        

}
